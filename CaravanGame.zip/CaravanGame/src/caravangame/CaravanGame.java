/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caravangame;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author alibashir
 */
public class CaravanGame{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {                 
        
        Caravan caravan = new Caravan();
        
        System.out.println("Hello Coordinator, We need your help evacating the animals, but first, we need your name!");
        caravan.playerName = caravan.scnr.nextLine().toUpperCase();
        System.out.println("Going to the next vehicle will add that vehicle to the current caravan."
                + "\nOnce you make a new caravan, you cannot go back and modiy the previous one."
                + "\nYou can still send out previous caravans and they will either fail the expedition or succeed."
                + "\nIf you run out of Caravans, a new day will automatically start."
                + "\nYOU MUST SEND OUT ALL 3 CARAVANS IN ORDER TO START THE NEXT DAY!");                
                
        
        caravan.mainPage();
System.out.println("END AGME");
      

    }
}

