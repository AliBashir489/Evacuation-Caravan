/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caravangame;
import java.util.Random;

/**
 *
 * @author alibashir
 */

public class Vehicle  {
    int animalCount;
    String vehicleType;
    Random rand = new Random();
    boolean hasTrailer;
    int trailerLength, trailerCapacity;
    int numDogs = 0, numCats = 0, numHorses = 0;
    String [] allInfo = new String[14];
    
    public static Vehicle generateRandomVehicle(){
        Random rand = new Random();
        Vehicle vehicleGenerator = null;
        int x = rand.nextInt(4);
            switch(x){
                case 0:                   
                    vehicleGenerator = new CompactCar();                  
                    break;
                case 1:                   
                    vehicleGenerator = new MidsizeCar();                  
                    break;
                case 2:                    
                    vehicleGenerator = new SUV();                    
                    break;
                case 3:                     
                    vehicleGenerator = new Truck();                  
                    break;                
            }
            return vehicleGenerator;
    }

    
    public void GenerateAnimals(){
        
        for(int y = 0; y<this.animalCount; y++){
            allInfo[y] = "";
            int z = rand.nextInt(2);
            
            if (z == 0){
                Dog dog = new Dog();
                numDogs+=1;
                for (int x = 0; x<7; x++){
                    allInfo[y] = allInfo[y].concat(dog.allAnimalInfo[x] + "\n");             
                }
            }

            else{
                Cat cat = new Cat();
                numCats+=1;
                for (int x = 0; x<7; x++){
                    allInfo[y] = allInfo[y].concat(cat.allAnimalInfo[x] + "\n");                        
                }     
            }
        }
        if (this.hasTrailer){
            for(int y = this.animalCount; y < this.animalCount + this.trailerCapacity; y++){
                allInfo[y] = "";
                Horse horse = new Horse();
                numHorses+=1;
                for (int x = 0; x<6; x++){
                    allInfo[y] = allInfo[y].concat(horse.allAnimalInfo[x] + "\n");
                }
                }
            }
        }
    
        
    
    public void displayVehicleInfo(){
        System.out.println(vehicleType.toUpperCase() + "\n--------");
        for (int x = 0; x < this.animalCount + this.trailerCapacity; x++){
            System.out.println(allInfo[x]);
            if (x == this.animalCount - 1 && this.hasTrailer){
                System.out.println("\n" + "Trailer Animals:" + "\n");
            }
        }
        System.out.println("--------\n");
    }
}

class CompactCar extends Vehicle{ 
    CompactCar(){
        this.animalCount = rand.nextInt(2) + 1;
        this.vehicleType = "Compact Car";
        GenerateAnimals(); 
    }
}

class MidsizeCar extends Vehicle{
    MidsizeCar(){
       this.animalCount = rand.nextInt(5)+1;
       this.vehicleType = "Midsize Car";
       GenerateAnimals();
    }
}


class SUV extends Vehicle{
   SUV(){
        this.animalCount = rand.nextInt(10) + 1;
        this.hasTrailer = rand.nextBoolean();
        if (hasTrailer) {
            this.trailerCapacity = rand.nextInt(2) == 1  ? 4 : 2;
            this.trailerLength = rand.nextInt(11) + 10;
        }
        this.vehicleType = "SUV";
        GenerateAnimals(); 
    }
}              
    
class Truck extends Vehicle {
   Truck(){
        this.animalCount = rand.nextInt(3) + 1;
        this.hasTrailer = rand.nextBoolean();
        if (hasTrailer) {
            this.trailerCapacity = rand.nextInt(2) == 1  ? 4 : 2;
            this.trailerLength = rand.nextInt(11) + 10;
        }
        this.vehicleType = "Truck";
        GenerateAnimals();   
    }
}

