/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caravangame;

/**
 *
 * @author alibashir
 */
 
import java.util.Scanner;

public class Caravan extends Vehicle{
    String playerName;
    Scanner scnr = new Scanner(System.in);
    String input;
    Vehicle[] caravan1VehicleList = new Vehicle[10];
    Vehicle[] caravan2VehicleList = new Vehicle[10];
    Vehicle[] caravan3VehicleList = new Vehicle[10];
    Vehicle[][] allCaravans = {caravan1VehicleList,caravan2VehicleList,caravan3VehicleList};
    int[] numVehiclesList = {0,0,0};
    int currentCaravan = 1;
    int numberOfCaravans = 1;
    int totalNumCaravans = 1;
    int totalDogs = 0;
    int totalCats = 0;
    int totalHorses = 0;
    int absTotalDogs = 0;
    int absTotalCats = 0;
    int absTotalHorses = 0;
    int dogsSaved = 0;
    int catsSaved = 0;
    int horsesSaved = 0;
    int dayNum = 1;
    int[] finishedCaravans = {1,-1,-1};
    double totalFinishedTrips = 0;
    double winTrips = 0;
    double lostTrips = 0;
    int totalComCar = 0;
    int totalMidCar = 0;
    int totalSUV = 0;
    int totalTruck = 0;
    int total2Trailer = 0;
    int total4Trailer = 0;
    
    
    
    
    public void mainPage(){
        Scanner scnrMain = new Scanner(System.in);
        
        System.out.println("\n" + playerName + " | DAY " + dayNum + " | You are currently viewing Caravan " 
            + currentCaravan + "   |   Currently Has " + numVehiclesList[currentCaravan - 1] + " Vehicles"
            + "\nEnter in what you would like to do:\n  \nNew Caravan - NC \nAdd Vehicle - AV "
            + "\nEvacuate Caravan - EC \nSelect Caravan - SC \nDisplay Caravan Passengers - DCP"
            + "\nStart New Day - SND \nABORT MISSION - !\n\n");         
        System.out.print("Enter Here: ");
        
        boolean correctInput = false;
        
        while (!correctInput){
            input = scnrMain.nextLine();
            switch (input) {
                case "NC":                    
                    correctInput = true;    
                    NewCaravan();
                    break;
                    
                case "AV":
                    correctInput = true;
                    AddVehicle();
                    break;
                case "EC":
                    correctInput = true;
                    SendCaravan();
                    break;
                
                case "SC":
                    correctInput = true;
                    SelectCaravan();
                    break;
                case "DCP":
                    correctInput = true;
                    DisplayPassengers();
                    break;
                case "SND":
                    correctInput = true;
                    changeDay();
                    break;
                case "!":
                    correctInput = true;
                    AbortMission();
                default:
                    System.out.println("\nPlease try again. Wrong Input");                    
                    break;
            }
        }
    }
    
    public void changeDay(){
        this.dayNum += 1;
        absTotalDogs += totalDogs;
        absTotalCats += totalCats;
        absTotalHorses += totalHorses;
        totalNumCaravans += numberOfCaravans;
        
        currentCaravan = 1;
        numberOfCaravans = 1;
        finishedCaravans = new int[]{1,-1,-1};
        caravan1VehicleList = new Vehicle[10];
        caravan2VehicleList = new Vehicle[10];
        caravan3VehicleList = new Vehicle[10];
        allCaravans = new Vehicle[][] {caravan1VehicleList,caravan2VehicleList,caravan3VehicleList};
        numVehiclesList = new int[]{0,0,0};
      
        
        mainPage();
    }
    
    public void DisplayPassengers(){
        System.out.println("\n---\nHere are the Vehicles/Passengers for Caravan " + currentCaravan
            + "\n-----\n");
        
        for (int x = 0; x < 10; x++){
            try{
                System.out.println(allCaravans[currentCaravan-1][x].vehicleType 
                    + "  -  " +  allCaravans[currentCaravan-1][x].numCats + " Cats  -  "
                    + allCaravans[currentCaravan-1][x].numDogs+ " Dogs  -  "
                    + allCaravans[currentCaravan-1][x].numHorses + " Horses\n");
            }
            catch(NullPointerException e){
                System.out.println("--Vacant Spot--\n");                
            }           
        }
        mainPage();
    }
    
    public void NewCaravan(){
        try{
            if (numberOfCaravans == 3){
                throw new Exception();
            }
            else{
                numberOfCaravans += 1; 
                totalNumCaravans += 1;
                System.out.println("\n\n\nCreated new Caravan: Caravan " + numberOfCaravans + "\n\n\n");   
                currentCaravan += 1;
                finishedCaravans[currentCaravan - 1] = currentCaravan;
                
            }
        }                    
        catch(Exception e){
            System.out.println("\n---\nCannot create new Caravan."
                + "\nThe maximum limit of 3 has been reached for the day. Send these ones out on expeditions, then change the day to create new!\n---\n");                        
        }       
        finally{
            mainPage();
        }
    }
    
    public void SelectCaravan(){
        if(numberOfCaravans == 1){
            System.out.println("\n---\nYou only have one caravan."
                    +  "\nMake a new Caravan to switch from your existing one!\n---\n\n");
            mainPage();
        }
        
        System.out.print("\n\nYou have " + numberOfCaravans + " Caravans."
            + "\nEnter the Caravan number you would like to switch to: ");
        
        while (true){         
            currentCaravan = scnr.nextInt();
            if (currentCaravan > numberOfCaravans || currentCaravan < 0){
                System.out.println("---\nThat caravan does not exist."
                        + "\nPlease enter a valid and existing Caravan number.\n---\n");                                
            }
            else{                
                mainPage();
            }        
        }                        
    }
    
    
    public void AddVehicle(){
        System.out.println("\n\n\n---");
         if (numVehiclesList[currentCaravan - 1] == 10){
            System.out.println("Limit 10 vehicles per caravan. You cannot add "
                + "any more vehicles to Caravan " + currentCaravan + "."
                + "\nPlease make another caravan or choose an exisitng one to add more Vehicles."
                + "\nIf all caravans are full, consider sending one out, " + playerName + "\n---\n");
            
            mainPage();
        }
         
        System.out.println("Here is the new Vehicle added to Caravan " 
                + currentCaravan + "." 
                + "\nKeep adding more vehicles "
                + "and animals until you are satisfied."
                + "\nBut keep in mind, the more vehicles/animals in the caravan, "
                + "the higher the chance of expedition failure.\n\n");
       
        Vehicle newVehicle = generateRandomVehicle();
        newVehicle.displayVehicleInfo();
        switch(newVehicle.vehicleType){
            case "Compact Car":
                totalComCar += 1;
                break;
            case "Midsize Car":
                totalMidCar += 1;
                break;
            case "SUV":
                totalSUV += 1;
                break;
            case "Truck":
                totalTruck += 1;
                break;
                
        }
        
        switch(newVehicle.trailerCapacity){
            case 2:
                total2Trailer += 1;
                break;
            case 4:
                total4Trailer += 1;
                break;                
        }
        
        allCaravans[currentCaravan-1][numVehiclesList[currentCaravan-1]] = newVehicle;
        numVehiclesList[currentCaravan - 1] += 1;            
           
        System.out.println("Enter in '+' to add another vehicle. Enter in "
                + "anything else to go back to headquarters.");
        input = scnr.nextLine();
        if(input.equals("+")){
            AddVehicle();
        }
        else{
            mainPage();
        }
        
    }
    
    
    
    public void SendCaravan(){
        int currentCaravanDogs = 0;
        int currentCaravanCats = 0;
        int currentCaravanHorses = 0;
        totalFinishedTrips += 1;
         
         for (int x = 0; x<10; x++){
             try{
                 totalDogs += allCaravans[currentCaravan-1][x].numDogs;
                 currentCaravanDogs += allCaravans[currentCaravan-1][x].numDogs;
             }
             catch(Exception e){
               
             }
             try{
                 totalCats+= allCaravans[currentCaravan-1][x].numCats;
                 currentCaravanDogs += allCaravans[currentCaravan-1][x].numCats;
             }
             catch(Exception e){
                 
             }
             try{
                 totalHorses += allCaravans[currentCaravan-1][x].numHorses;  
                 currentCaravanHorses += allCaravans[currentCaravan-1][x].numHorses;
             }
             catch(Exception e){
                 
             }                              
        }
        
            
        System.out.println("\n\n\nCoordinator, which route would you like to take? 1, 2, or 3\n"
                + "We have heard from one of the scouts that one of the routes has only a 20% chance of failure."
                + "\nSadly he didnt come back, so we don't know which of the three it is.\n");
        input = scnr.next();
        
        if (input.equals("1")){
            if (rand.nextInt(100) > 19){
                System.out.println("The expedition was successful!!!");
                dogsSaved += currentCaravanDogs;
                catsSaved += currentCaravanCats;
                horsesSaved += currentCaravanHorses;
                winTrips += 1;
                
            }
            else{
                System.out.println("The expedition failed and the caravan was lost!\n");   
                lostTrips += 1;
            }
        }
        
        else if (input.equals("2") || input.equals("3")){
            if (rand.nextInt(101)+1 > ((totalDogs+totalCats+totalHorses) * .5)){
                System.out.println("The expedition was successful!!!");
                dogsSaved += currentCaravanDogs;
                catsSaved += currentCaravanCats;
                horsesSaved += currentCaravanHorses;
                winTrips += 1;
            }
            else{
                System.out.println("The expedition failed and the caravan was lost!\n");
                lostTrips += 1;
            }
            
        }
        
        else{
            System.out.println("\n\nWrong Input. Going back to main page\n");
            mainPage();
            
        }
            
        
        finishedCaravans[currentCaravan-1] = 0;
        //numberOfCaravans-=1;
        for (int x = 0; x < 3; x++){
            if(finishedCaravans[x] != 0 && finishedCaravans[x] != -1){
                currentCaravan = x+1;
                mainPage();
            }
            else if(finishedCaravans[x] == -1){
                NewCaravan();
            }
        }
        
        System.out.println("\n\nYou do not have any more Caravans in this day, so we will start the next day.");
        changeDay();
       
    }
    
    public void AbortMission(){
        String userClass;
        if (winTrips < 6){
            userClass = "Beginner";
        }
        else if(winTrips < 13){
            userClass = "Amateur";
        }
        else if(winTrips < 19){
            userClass = "Intermediate";
        }
        else if(winTrips < 25){
            userClass = "Advanced";
        }
        else{
            userClass = "Expert";
        }
        
        System.out.println("GAME FINISHED> PRINTING RESUTS\n\n\n");
        System.out.println("Name: " + playerName);
        System.out.println("Days in Operation: " + dayNum);
        System.out.println("Total Number of Caravans: " + totalNumCaravans);
        System.out.println("Total Trips: " + totalFinishedTrips + " | "
                + "Successful Trips: " + winTrips + "   " 
                + (winTrips/totalFinishedTrips)*100.00 
                + "% | Failed Trips: " + lostTrips + "   " 
                + (lostTrips/totalFinishedTrips)*100.00 + "%");
        
        System.out.println("Total Dogs: " + absTotalDogs + " | Saved: " + dogsSaved);
        System.out.println("Total Cats: " + absTotalCats + " | Saved: " + catsSaved);
        System.out.println("Total Horses: " + absTotalHorses + " | Saved: " + horsesSaved);
        System.out.println("Total Compact Cars: " + totalComCar);
        System.out.println("Total Midsize Cars: " + totalMidCar);
        System.out.println("Total SUVs: " + totalSUV);
        System.out.println("Total Trucks: " + totalTruck);
        System.out.println("Total 4 Horse Trailers: " + total4Trailer);
        System.out.println("Total 2 Horse Trailers: " + total2Trailer);
        
        System.out.println("\n\nBased on your results, you seem to be an " + userClass + " Player!\n");
        System.exit(0);
        
    }
        
}


