/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caravangame;

/**
 *
 * @author alibashir
 */

import java.util.Random;

public class Animal {
    
    public String name, animalType, ownerName;
    public int weight, ID;
    public String[] allAnimalInfo = new String[7];
    Random rand = new Random();
    
    public String[] pottyLitterPossibilities = {"morning", "afternoon",
        "evening", "night", "previous day" };
    
    public String [] nameList = {"Max", "Bella", "Charlie", "Luna", "Cooper", 
        "Lucy", "Buddy", "Daisy", "Rocky", "Lily", "Milo", "Zoe", "Jack", "Lola",
        "Bear", "Molly", "Duke", "Sadie", "Teddy", "Bailey"};
    
    public Animal(String animalType){
       this.name = nameList[rand.nextInt(20)];
       this.ownerName = nameList[rand.nextInt(20)];
       
       if (animalType.equals("Horse")){
           this.weight = rand.nextInt(501) + 500; // 500 to 1000
       }
       else if (animalType.equals("Dog")){
           this.weight = rand.nextInt(51) + 50; // 50 - 100
       }
       else{
           this.weight = rand.nextInt(11) + 5; // 5 - 15
       }
       
       this.ID = rand.nextInt(1000000) + 1000000;
       
       allAnimalInfo[1] = "Name: " + this.name;
       allAnimalInfo[2] = "Owner Name: " + this.ownerName;
       allAnimalInfo[3] = "Weight: " + this.weight + " lbs";
       allAnimalInfo[4] = "ID: " + this.ID;  
       
    }
    
   
    
}



class Dog extends Animal {
    
    public boolean hasLeash;
    public String lastPottyBreak;
    
    
    Dog(){
        super("Dog");
        this.hasLeash = rand.nextBoolean();
        this.lastPottyBreak = pottyLitterPossibilities[rand.nextInt(4)];
        this.animalType= "Dog";
        allAnimalInfo[0] = "Animal: " + this.animalType;
        allAnimalInfo[5] = "Has A Leash: " + this.hasLeash;
        allAnimalInfo[6] = "Last Potty Break: " + this.lastPottyBreak;
    }
    
}


class Cat extends Animal{
    
    public boolean hasLitterBox;
    public String lastLitterClean;
    
    Cat(){  
        super("Cat");
        this.hasLitterBox = rand.nextBoolean();
        this.lastLitterClean = pottyLitterPossibilities[rand.nextInt(5)];
        this.animalType = "Cat";
        allAnimalInfo[0] = "Animal: " + this.animalType;
        allAnimalInfo[5] = "Has A Litter Box: " + this.hasLitterBox;
        allAnimalInfo[6] = "Last Litter Clean Time: " + this.lastLitterClean;
       
    }
}

class Horse extends Animal{
    
    public boolean hasHay;
    
    Horse(){
        super("Horse");
        this.hasHay = rand.nextBoolean();
        this.animalType = "Horse";
        allAnimalInfo[0] = "Animal: " + this.animalType;
        allAnimalInfo[5] = "Has Hay: " + this.hasHay;
        
    }
}